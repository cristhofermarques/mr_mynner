﻿using System;
using System.Collections.Generic;
using FlaxEngine;
using MrMynner.Scripts;
using MrMynner.Actors;

namespace Game
{
    /// <summary>
    /// Test Script.
    /// </summary>
    public class Test : Script
    {
        public CableActor spline;

        public override void OnUpdate()
        {

            if(spline == null){return;}

            if(Input.GetKeyDown(KeyboardKeys.Q))
            {
                if(spline.SplinePointsCount > 2)
                {
                    int idx = 1;
                    //Debug.Log(spline.SplineKeyframes.Length);
                    spline.SetSplinePoint(idx, Actor.Position);
                    //Debug.Log(spline.SplineKeyframes.Length);
                    float len = spline.SplineLength;
                }
            }
        }


    }
}
